// ==========================================
// 1. Banner Rotativo de Destaque / Propaganda
// ==========================================
const bannerSlides = document.querySelectorAll(".banner-slide");
const bannerDots = document.querySelectorAll("#banner-indicadores .b-dot");
const bannerSlider = document.querySelector(".banner-slider");

let slideAtual = 0;
let bannerInterval = null;
const TEMPO_ROTACAO = 4000; // 4 segundos por imagem

function mostrarSlide(index) {
    if (!bannerSlides.length) return;

    if (index >= bannerSlides.length) {
        slideAtual = 0;
    } else if (index < 0) {
        slideAtual = bannerSlides.length - 1;
    } else {
        slideAtual = index;
    }

    bannerSlides.forEach((slide, i) => {
        slide.classList.toggle("active", i === slideAtual);
    });

    bannerDots.forEach((dot, i) => {
        dot.classList.toggle("active", i === slideAtual);
    });
}

function banner_proximo() {
    mostrarSlide(slideAtual + 1);
    reiniciarAutoPlay();
}

function banner_anterior() {
    mostrarSlide(slideAtual - 1);
    reiniciarAutoPlay();
}

function ir_para_slide_banner(index) {
    mostrarSlide(index);
    reiniciarAutoPlay();
}

function iniciarAutoPlay() {
    pararAutoPlay();
    bannerInterval = setInterval(() => {
        mostrarSlide(slideAtual + 1);
    }, TEMPO_ROTACAO);
}

function pararAutoPlay() {
    if (bannerInterval) {
        clearInterval(bannerInterval);
        bannerInterval = null;
    }
}

function reiniciarAutoPlay() {
    pararAutoPlay();
    iniciarAutoPlay();
}

// Pausar rotação ao passar o mouse sobre o banner
if (bannerSlider) {
    bannerSlider.addEventListener("mouseenter", pararAutoPlay);
    bannerSlider.addEventListener("mouseleave", iniciarAutoPlay);
}

// ==========================================
// 2. Vitrine Superior de Jogos
// ==========================================
const vitrine = document.getElementById("vitrine");
let posicaoAtual = 0;
const passo = 260; // Deslocamento aproximado de 1 card + gap

function getLimites() {
    if (!vitrine || !vitrine.parentElement) return { maxScroll: 0 };
    const larguraTotal = vitrine.scrollWidth;
    const larguraContainer = vitrine.parentElement.clientWidth;
    const maxScroll = -(larguraTotal - larguraContainer);
    return { maxScroll: Math.min(0, maxScroll) };
}

function arrasta_esquerda() {
    posicaoAtual += passo;
    if (posicaoAtual > 0) {
        posicaoAtual = 0;
    }
    atualizarPosicao();
}

function arrasta_direita() {
    const { maxScroll } = getLimites();
    posicaoAtual -= passo;
    if (posicaoAtual < maxScroll) {
        posicaoAtual = maxScroll;
    }
    atualizarPosicao();
}

function atualizarPosicao() {
    if (vitrine) {
        vitrine.style.transform = `translateX(${posicaoAtual}px)`;
    }
}

// ==========================================
// 3. Galeria de Ofertas de Lançamento
// ==========================================
const galeriaTrack = document.getElementById("galeria-track");
const btnGaleriaPrev = document.getElementById("galeria-prev");
const btnGaleriaNext = document.getElementById("galeria-next");
const containerGaleria = document.getElementById("galeria-container");
const indicadores = document.querySelectorAll("#galeria-indicadores .dot");

let paginaAtualGaleria = 0;

function getTotalPaginasGaleria() {
    if (!galeriaTrack || !containerGaleria) return 2;
    const larguraItem = galeriaTrack.children[0] ? galeriaTrack.children[0].offsetWidth + 20 : 1;
    const itensVisiveis = Math.round(containerGaleria.offsetWidth / larguraItem) || 3;
    const totalItens = galeriaTrack.children.length || 6;
    return Math.ceil(totalItens / itensVisiveis);
}

function atualizarGaleria() {
    if (!galeriaTrack || !containerGaleria) return;

    const totalPaginas = getTotalPaginasGaleria();

    // Limitar índice
    if (paginaAtualGaleria < 0) paginaAtualGaleria = 0;
    if (paginaAtualGaleria >= totalPaginas) paginaAtualGaleria = totalPaginas - 1;

    // Calcular deslocamento: move o tamanho visível do container + gap por página
    const deslocamento = paginaAtualGaleria * (containerGaleria.offsetWidth + 20);
    galeriaTrack.style.transform = `translateX(-${deslocamento}px)`;

    // Atualizar estados dos botões
    if (btnGaleriaPrev) {
        btnGaleriaPrev.disabled = paginaAtualGaleria === 0;
    }
    if (btnGaleriaNext) {
        btnGaleriaNext.disabled = paginaAtualGaleria >= totalPaginas - 1;
    }

    // Atualizar indicadores visuais (dots)
    indicadores.forEach((dot, index) => {
        dot.classList.toggle("active", index === paginaAtualGaleria);
    });
}

function galeria_proximo() {
    const totalPaginas = getTotalPaginasGaleria();
    if (paginaAtualGaleria < totalPaginas - 1) {
        paginaAtualGaleria++;
        atualizarGaleria();
    }
}

function galeria_anterior() {
    if (paginaAtualGaleria > 0) {
        paginaAtualGaleria--;
        atualizarGaleria();
    }
}

function ir_para_pagina_galeria(index) {
    paginaAtualGaleria = index;
    atualizarGaleria();
}

// ==========================================
// Inicialização Geral
// ==========================================
window.addEventListener("DOMContentLoaded", () => {
    atualizarGaleria();
    iniciarAutoPlay();
});

// Recalcular posições no redimensionamento da tela
window.addEventListener("resize", () => {
    // Vitrine
    const { maxScroll } = getLimites();
    if (posicaoAtual < maxScroll) {
        posicaoAtual = maxScroll;
        atualizarPosicao();
    }

    // Galeria
    atualizarGaleria();
});
